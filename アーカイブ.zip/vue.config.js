module.exports = {
  publicPath: './', // ビルド後のパスを相対パスに
  outputDir: 'dist', // ビルド出力先ディレクトリ (任意)
  assetsDir: '', // 静的アセットのディレクトリ (任意)
};