<script setup>
import { ref } from 'vue';
import { useImageStore } from '@/stores/image.js'
const image = useImageStore()

import { useCoordinateStore } from '@/stores/image.js'
const coordinate = useImageStore()

const imageUrl = ref(null);

const file = image.data

// FileReader API を使って画像データを base64 文字列に変換
const reader = new FileReader();
reader.readAsDataURL(file);
reader.onload = () => {
  imageUrl.value = reader.result;
};

const xPos = ref(0)
const yPos = ref(0)

const getClickPosition = (event) => {
  const image = event.target
  const rect = image.getBoundingClientRect()  // 画像の位置とサイズを取得

  // 画像内の相対座標を計算
  xPos.value = event.clientX - rect.left
  yPos.value = event.clientY - rect.top

  coordinate.data = {"xPos": xPos, "yPos": yPos}
}
</script>
<template>
  <img v-if="imageUrl" :src="imageUrl" alt="アップロードされた画像" class="w-[100vw]" @click="getClickPosition">
  <p class="text-white">{{ xPos }},{{ yPos }}</p>
</template>