<template>
  <div class="h-dvh w-screen backdrop-blur-sm bg-black/30">
    <div class="relative h-dvh">
      <div class="dots relative top-1/2 translate-y-(-50%) mx-auto"></div>
    </div>
  </div>
</template>